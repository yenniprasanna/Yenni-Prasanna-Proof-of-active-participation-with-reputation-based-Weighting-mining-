-- db_init.sql - Robust PostgreSQL Database Initialization Script
-- This script will be run by the PostgreSQL container on its first startup,
-- or if the 'postgres_data' volume (which persists the database) is deleted.
-- It uses IF NOT EXISTS to make user and database creation idempotent (safe to run multiple times).

-- Create the 'web3user' role (user) if it doesn't already exist.
-- The PASSWORD must match the DB_PASSWORD defined in your backend/.env file and docker-compose.yml.
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'web3user') THEN
        CREATE ROLE web3user WITH LOGIN PASSWORD 'ssdvcssdvc7$'; -- IMPORTANT: REPLACE 'ssdvcssdvc7$' with your actual strong DB password!
    END IF;
END
$$;

-- Create the 'poaprwb_db' database if it doesn't already exist.
-- Assign 'web3user' as the owner of this database.
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_database WHERE datname = 'poaprwb_db') THEN
        CREATE DATABASE poaprwb_db WITH OWNER web3user;
    END IF;
END
$$;

-- Connect to the 'poaprwb_db' database to create tables within its context.
-- The Docker entrypoint script handles connecting implicitly for subsequent SQL commands.

-- Create the 'nodes' table to store node profiles and their current reputation.
-- 'node_id' is the Solana PublicKey of the NodeProfileAccount PDA.
CREATE TABLE IF NOT EXISTS nodes (
    node_id VARCHAR(255) PRIMARY KEY, -- Solana PublicKey (e.g., base58 string)
    operator_public_key VARCHAR(255) NOT NULL, -- The actual operator's public key (e.g., base58 string)
    metadata_url TEXT, -- URL to off-chain metadata (e.g., node description, specs, IPFS link)
    reputation_score INTEGER NOT NULL DEFAULT 0,
    reputation_tier VARCHAR(50) NOT NULL DEFAULT 'Bronze',
    sybil_risk_factor INTEGER NOT NULL DEFAULT 0, -- 0-100 scale, representing risk level
    last_reputation_update TIMESTAMP WITH TIME ZONE, -- Timestamp of the last reputation score update
    is_active BOOLEAN NOT NULL DEFAULT TRUE, -- Flag indicating if the node is currently active
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP -- Timestamp when this node record was created
);

-- Create the 'participation_events' table to log individual node participation activities.
CREATE TABLE IF NOT EXISTS participation_events (
    id SERIAL PRIMARY KEY, -- Unique ID for each participation event record
    node_id VARCHAR(255) NOT NULL REFERENCES nodes(node_id), -- Foreign key linking to the 'nodes' table
    activity_type VARCHAR(100) NOT NULL, -- Type of activity (e.g., 'BlockProposal', 'GovernanceVote', 'CodeContribution')
    activity_hash VARCHAR(64) UNIQUE NOT NULL, -- Unique hash of the on-chain proof (e.g., Solana Transaction ID, IPFS hash)
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL, -- Timestamp when the activity actually occurred (from the blockchain/external source)
    verifier VARCHAR(255) NOT NULL, -- The public key or identifier of the entity that verified/submitted this event (e.g., an Oracle)
    additional_data_url TEXT, -- URL to more detailed proof or more context (e.g., full transaction link)
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP -- Timestamp when this event was recorded in the database
);

-- Create the 'reputation_history' table to log historical changes in node reputation scores.
CREATE TABLE IF NOT EXISTS reputation_history (
    id SERIAL PRIMARY KEY, -- Unique ID for each historical record
    node_id VARCHAR(255) NOT NULL REFERENCES nodes(node_id), -- Foreign key linking to the 'nodes' table
    reputation_score INTEGER NOT NULL, -- The reputation score at this historical point
    reputation_tier VARCHAR(50) NOT NULL, -- The reputation tier at this historical point
    sybil_risk_factor INTEGER NOT NULL, -- The sybil risk factor at this historical point
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL, -- The timestamp of the reputation update that this record represents
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP -- Timestamp when this historical record was added to the database
);
