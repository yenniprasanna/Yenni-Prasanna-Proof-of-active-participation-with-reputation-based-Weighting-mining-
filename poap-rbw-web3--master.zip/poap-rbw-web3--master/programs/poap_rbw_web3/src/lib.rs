```rust
// programs/poap_rbw_web3/src/lib.rs - Your Solana Smart Contract Code
use anchor_lang::prelude::*;
use anchor_spl::token::{self, Mint, Token, TokenAccount};

// This macro declares your program's unique ID.
// It will be automatically updated by `anchor deploy` after a successful deployment
// to reflect the actual on-chain program address.
declare_id!("YOUR_PROGRAM_ID_HERE"); // Placeholder: Will be overwritten on deploy

// #[program] macro defines the entry points for your Solana program.
// Each public function within this module corresponds to an instruction that clients can call.
#[program]
pub mod poap_rbw_web3 {
    use super::*;

    /// Registers a new node in the system.
    /// This account will hold the node's current reputation score.
    pub fn register_node(ctx: Context<RegisterNode>, node_metadata_url: String) -> Result<()> {
        let node_profile = &mut ctx.accounts.node_profile;
        node_profile.operator = ctx.accounts.operator.key();
        node_profile.reputation_score = 0; // Initialize reputation to 0
        node_profile.last_reputation_update = Clock::get()?.unix_timestamp;
        node_profile.is_active = true;
        node_profile.node_metadata_url = node_metadata_url;

        emit!(NodeRegisteredEvent {
            node_id: node_profile.key(),
            operator: node_profile.operator,
            timestamp: Clock::get()?.unix_timestamp,
        });
        Ok(())
    }

    /// Records a specific Proof of Participation (PoP) event for a node.
    /// This is where verifiable on-chain actions contribute.
    pub fn submit_participation_proof(
        ctx: Context<SubmitParticipationProof>,
        activity_type: String, // e.g., "BlockProposal", "GovernanceVote", "CodeContribution"
        activity_hash: [u8; 32], // Hash of the specific activity proof/transaction
        additional_data_url: String, // Link to off-chain proof details (e.g., IPFS)
    ) -> Result<()> {
        let record = &mut ctx.accounts.participation_record;
        record.node_id = ctx.accounts.node_profile.key();
        record.activity_type = activity_type;
        record.activity_hash = activity_hash;
        record.timestamp = Clock::get()?.unix_timestamp;
        record.verified_by = ctx.accounts.verifier.key(); // Could be self, or a trusted entity
        record.additional_data_url = additional_data_url;

        // Optionally, add a simple check for basic PoP verification here,
        // but complex quality assessment is for the ML module.
        // For example: require!(ctx.accounts.verifier.key() == ctx.accounts.node_profile.operator, ErrorCode::UnauthorizedPoPSubmission);

        emit!(ParticipationRecordedEvent {
            node_id: record.node_id,
            activity_type: record.activity_type.clone(),
            activity_hash: record.activity_hash,
            timestamp: record.timestamp,
        });

        Ok(())
    }

    /// **CRITICAL:** Updates a node's on-chain reputation score.
    /// This instruction must ONLY be callable by a trusted oracle (your Node.js backend).
    pub fn update_node_reputation(
        ctx: Context<UpdateNodeReputation>,
        new_score: u64,
        reputation_tier: String,
        sybil_risk_factor: u64, // e.g., 0-100, 0=low risk, 100=high risk
    ) -> Result<()> {
        let node_profile = &mut ctx.accounts.node_profile;
        let oracle_authority = &ctx.accounts.oracle_authority;

        // Ensure only the designated oracle PDA can call this instruction
        require!(oracle_authority.key() == ctx.accounts.expected_oracle_pda.key(), ErrorCode::UnauthorizedOracle);

        node_profile.reputation_score = new_score;
        node_profile.last_reputation_update = Clock::get()?.unix_timestamp;
        node_profile.reputation_tier = reputation_tier;
        node_profile.sybil_risk_factor = sybil_risk_factor;

        emit!(ReputationUpdatedEvent {
            node_id: node_profile.key(),
            new_score,
            timestamp: Clock::get()?.unix_timestamp,
            tier: node_profile.reputation_tier.clone(),
            sybil_risk: node_profile.sybil_risk_factor,
        });

        Ok(())
    }

    /// (Conceptual) Allows other on-chain programs or off-chain clients
    /// to query a node's weighted influence based on its reputation.
    /// This might just be a simple read from the NodeProfileAccount.
    pub fn get_weighted_influence(ctx: Context<GetWeightedInfluence>) -> Result<()> {
        let node_profile = &ctx.accounts.node_profile;
        let config = &ctx.accounts.resource_weighting_config;

        // Simple example: influence multiplier based on tier
        let mut influence_multiplier: u64 = 1; // Default
        if node_profile.reputation_tier == "Gold" {
            influence_multiplier = config.gold_tier_multiplier;
        } else if node_profile.reputation_tier == "Silver" {
            influence_multiplier = config.silver_tier_multiplier;
        }
        // More complex logic can be here, or derived off-chain using the score

        // This instruction might not return a value directly (Solana instructions are void).
        // It's more about side effects or simply allowing client to read the account.
        // For actual validator weighting, this account would be read directly by validator logic.

        emit!(WeightedInfluenceQueriedEvent {
            node_id: node_profile.key(),
            reputation_score: node_profile.reputation_score,
            tier: node_profile.reputation_tier.clone(),
            influence_multiplier,
        });

        Ok(())
    }

    /// Initializes a global configuration account for resource weighting.
    /// Only callable by the deployer/admin.
    pub fn initialize_resource_weighting_config(
        ctx: Context<InitializeResourceWeightingConfig>,
        gold_tier_min_score: u64,
        gold_tier_multiplier: u64,
        silver_tier_min_score: u64,
        silver_tier_multiplier: u64,
    ) -> Result<()> {
        let config = &mut ctx.accounts.resource_weighting_config;
        config.admin = ctx.accounts.admin.key();
        config.gold_tier_min_score = gold_tier_min_score;
        config.gold_tier_multiplier = gold_tier_multiplier;
        config.silver_tier_min_score = silver_tier_min_score;
        config.silver_tier_multiplier = silver_tier_multiplier;
        Ok(())
    }
}

// ----------------------------------------------------------------------------
// ACCOUNT STRUCTS
// ----------------------------------------------------------------------------

#[account]
#[derive(Default)]
pub struct NodeProfileAccount {
    pub operator: Pubkey,         // The public key controlling this node
    pub reputation_score: u64,    // Calculated reputation (0-1000 or similar)
    pub last_reputation_update: i64, // Timestamp of last update
    pub is_active: bool,          // Whether the node is currently active
    pub node_metadata_url: String, // Link to off-chain node details (e.g., IPFS hash)
    pub reputation_tier: String,  // e.g., "Bronze", "Silver", "Gold"
    pub sybil_risk_factor: u64,   // ML-derived risk factor (0-100)
}

#[account]
#[derive(Default)]
pub struct ParticipationRecordAccount {
    pub node_id: Pubkey,          // The node that performed the activity
    pub activity_type: String,    // e.g., "BlockProposal", "GovernanceVote"
    pub activity_hash: [u8; 32],  // Unique hash identifying the specific activity/proof
    pub timestamp: i64,           // When the activity occurred
    pub verified_by: Pubkey,      // The entity that verified/submitted this proof
    pub additional_data_url: String, // URL to more details about the activity (e.g., Tx ID, IPFS link)
}

#[account]
pub struct ResourceWeightingConfig {
    pub admin: Pubkey,
    pub gold_tier_min_score: u64,
    pub gold_tier_multiplier: u64,
    pub silver_tier_min_score: u64,
    pub silver_tier_multiplier: u64,
    // Add other tiers or config values as needed
}

// ----------------------------------------------------------------------------
// CONTEXT STRUCTS
// ----------------------------------------------------------------------------

#[derive(Accounts)]
#[instruction(node_metadata_url: String)]
pub struct RegisterNode<'info> {
    #[account(
        init,
        payer = operator,
        space = 8 + 32 + 8 + 1 + (4 + node_metadata_url.len()) + (4 + 20) + 8, // ~100 bytes + string lengths
        seeds = [b"node_profile", operator.key().as_ref()], // PDA for node profile
        bump
    )]
    pub node_profile: Account<'info, NodeProfileAccount>,
    #[account(mut)]
    pub operator: Signer<'info>, // The keypair creating/controlling the node
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(activity_type: String, activity_hash: [u8; 32], additional_data_url: String)]
pub struct SubmitParticipationProof<'info> {
    #[account(mut, seeds = [b"node_profile", node_profile.operator.key().as_ref()], bump = node_profile.bump)]
    pub node_profile: Account<'info, NodeProfileAccount>, // The node's profile being updated
    #[account(
        init,
        payer = verifier,
        space = 8 + 32 + (4 + activity_type.len()) + 32 + 8 + 32 + (4 + additional_data_url.len()), // Example space
        seeds = [b"participation_record", node_profile.key().as_ref(), &activity_hash], // Unique PDA for each record
        bump
    )]
    pub participation_record: Account<'info, ParticipationRecordAccount>,
    #[account(mut)]
    pub verifier: Signer<'info>, // The one submitting/paying for the proof (could be node operator or another oracle)
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(new_score: u64, reputation_tier: String, sybil_risk_factor: u64)]
pub struct UpdateNodeReputation<'info> {
    #[account(mut, seeds = [b"node_profile", node_profile.operator.key().as_ref()], bump = node_profile.bump)]
    pub node_profile: Account<'info, NodeProfileAccount>,
    /// CHECK: This is the trusted oracle account that is authorized to update reputation.
    /// Its address must match the expected PDA derived from a known seed.
    #[account(mut)]
    pub oracle_authority: Signer<'info>, // The backend's authority
    /// CHECK: PDA of the expected oracle authority, for verification.
    #[account(seeds = [b"oracle_authority_seed"], bump)] // Replace "oracle_authority_seed" with a fixed seed
    pub expected_oracle_pda: AccountInfo<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct GetWeightedInfluence<'info> {
    #[account(seeds = [b"node_profile", node_profile.operator.key().as_ref()], bump = node_profile.bump)]
    pub node_profile: Account<'info, NodeProfileAccount>,
    #[account(seeds = [b"resource_weighting_config"], bump)]
    pub resource_weighting_config: Account<'info, ResourceWeightingConfig>,
}

#[derive(Accounts)]
#[instruction(gold_tier_min_score: u64, gold_tier_multiplier: u64, silver_tier_min_score: u64, silver_tier_multiplier: u64)]
pub struct InitializeResourceWeightingConfig<'info> {
    #[account(
        init,
        payer = admin,
        space = 8 + 32 + 8 + 8 + 8 + 8, // Adjust based on fields
        seeds = [b"resource_weighting_config"],
        bump
    )]
    pub resource_weighting_config: Account<'info, ResourceWeightingConfig>,
    #[account(mut)]
    pub admin: Signer<'info>, // The deployer/admin key
    pub system_program: Program<'info, System>,
}

// ----------------------------------------------------------------------------
// EVENTS
// ----------------------------------------------------------------------------

#[event]
pub struct NodeRegisteredEvent {
    pub node_id: Pubkey,
    pub operator: Pubkey,
    pub timestamp: i64,
}

#[event]
pub struct ParticipationRecordedEvent {
    pub node_id: Pubkey,
    pub activity_type: String,
    pub activity_hash: [u8; 32],
    pub timestamp: i64,
}

#[event]
pub struct ReputationUpdatedEvent {
    pub node_id: Pubkey,
    pub new_score: u64,
    pub timestamp: i64,
    pub tier: String,
    pub sybil_risk: u64,
}

#[event]
pub struct WeightedInfluenceQueriedEvent {
    pub node_id: Pubkey,
    pub reputation_score: u64,
    pub tier: String,
    pub influence_multiplier: u64,
}

// ----------------------------------------------------------------------------
// ERRORS
// ----------------------------------------------------------------------------

#[error_code]
pub enum ErrorCode {
    #[msg("Unauthorized oracle to update reputation.")]
    UnauthorizedOracle,
    #[msg("Node is not active.")]
    NodeNotActive,
    #[msg("Invalid activity type.")]
    InvalidActivityType,
    #[msg("Unauthorized to submit participation proof.")]
    UnauthorizedPoPSubmission,
    // Add more specific errors
}
```