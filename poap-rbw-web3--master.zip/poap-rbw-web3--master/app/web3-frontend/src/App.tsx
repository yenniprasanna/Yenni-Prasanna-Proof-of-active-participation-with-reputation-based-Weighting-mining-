```typescript
// app/web3-frontend/src/App.tsx
import React, { FC, useMemo, useState, useEffect, useCallback } from 'react';
import { ConnectionProvider, WalletProvider, useWallet, useConnection } from '@solana/wallet-adapter-react';
import { WalletAdapterNetwork } from '@solana/wallet-adapter-base';
import { PhantomWalletAdapter, SolflareWalletAdapter } from '@solana/wallet-adapter-wallets';
import { WalletModalProvider, WalletDisconnectButton, WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { clusterApiUrl, PublicKey, SystemProgram, Transaction } from '@solana/web3.js';
import { Program, AnchorProvider, web3 } from '@project-serum/anchor';
import { Buffer } from 'buffer'; // For Node.js/browser compatibility

import idl from './poap_rbw_web3.json'; // IMPORTANT: Copy this file from target/idl after anchor build
import './App.css'; // Basic CSS

// Helper for Program ID
const programID = new PublicKey(idl.metadata.address);
const backendPort = 5000; // Your backend port

// Custom Hook to manage Solana program interaction
const useSolanaProgram = () => {
    const { connection } = useConnection();
    const wallet = useWallet();

    const provider = useMemo(() => {
        if (wallet.publicKey) {
            return new AnchorProvider(connection, wallet as any, AnchorProvider.defaultOptions());
        }
        return null;
    }, [connection, wallet]);

    const program = useMemo(() => {
        if (provider) {
            return new Program(idl as any, programID, provider);
        }
        return null;
    }, [provider]);

    return { program, provider, wallet };
};

interface NodeData {
    node_id: string;
    operator_public_key: string;
    metadata_url: string;
    reputation_score: number;
    reputation_tier: string;
    sybil_risk_factor: number;
    last_reputation_update: string;
    is_active: boolean;
}

const App: FC = () => {
    const { program, provider, wallet } = useSolanaProgram();
    const [message, setMessage] = useState('');
    const [nodes, setNodes] = useState<NodeData[]>([]);
    const [newNodeOperator, setNewNodeOperator] = useState('');
    const [newNodeMetadataUrl, setNewNodeMetadataUrl] = useState('');
    const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);

    const fetchNodes = useCallback(async () => {
        try {
            setMessage('Fetching nodes...');
            const response = await fetch(`http://localhost:${backendPort}/api/nodes`);
            if (!response.ok) throw new Error('Failed to fetch nodes');
            const data = await response.json();
            setNodes(data);
            setMessage('Nodes fetched successfully.');
        } catch (error) {
            console.error('Error fetching nodes:', error);
            setMessage(`Error fetching nodes: ${error instanceof Error ? error.message : String(error)}`);
        }
    }, []);

    useEffect(() => {
        fetchNodes();
    }, [fetchNodes]);

    const handleRegisterNode = async () => {
        if (!provider || !program || !wallet.publicKey) {
            setMessage('Wallet not connected.');
            return;
        }
        if (!newNodeOperator || !newNodeMetadataUrl) {
            setMessage('Please fill in all node registration fields.');
            return;
        }

        setMessage('Registering node...');
        try {
            const operatorPubKey = new PublicKey(newNodeOperator);
            const [nodeProfilePda] = PublicKey.findProgramAddressSync(
                [Buffer.from("node_profile"), operatorPubKey.toBuffer()],
                programID
            );

            // In a real scenario, the node operator (newNodeOperator) would sign this.
            // For simplicity, we are using the connected wallet to sign here,
            // or the backend oracle could submit it if this is an admin function.
            // Adjust based on who is expected to pay for and sign the `register_node` instruction.
            const tx = await program.methods.registerNode(newNodeMetadataUrl)
                .accounts({
                    nodeProfile: nodeProfilePda,
                    operator: wallet.publicKey, // Current connected wallet as operator/payer
                    systemProgram: SystemProgram.programId,
                })
                .rpc();

            setMessage(`Node registered on-chain! Tx: ${tx}`);
            console.log('On-chain registration Tx:', tx);

            // Now, tell the backend to record this node (if it's not done via event listener)
            const backendResponse = await fetch(`http://localhost:${backendPort}/api/nodes/register`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    nodeId: nodeProfilePda.toBase58(), // Use the PDA as the node_id
                    operatorPublicKey: newNodeOperator,
                    nodeMetadataUrl: newNodeMetadataUrl
                })
            });
            if (!backendResponse.ok) throw new Error('Failed to register node in backend');
            const backendData = await backendResponse.json();
            console.log('Backend registration response:', backendData);

            setMessage('Node registered successfully!');
            fetchNodes(); // Refresh the list
            setNewNodeOperator('');
            setNewNodeMetadataUrl('');
        } catch (error) {
            console.error('Error registering node:', error);
            setMessage(`Error registering node: ${error instanceof Error ? error.message : String(error)}`);
        }
    };

    const handleTriggerReputationRecalculation = async (nodeId: string) => {
        setMessage(`Triggering reputation recalculation for ${nodeId}...`);
        try {
            const response = await fetch(`http://localhost:${backendPort}/api/reputation/calculate/${nodeId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            });
            if (!response.ok) throw new Error('Failed to trigger recalculation');
            const data = await response.json();
            setMessage(`Reputation recalculation triggered! New score: ${data.newReputation}. Tx: ${data.txHash}`);
            fetchNodes(); // Refresh the list
        } catch (error) {
            console.error('Error triggering recalculation:', error);
            setMessage(`Error triggering recalculation: ${error instanceof Error ? error.message : String(error)}`);
        }
    };

    const handleViewNodeDetails = (nodeId: string) => {
        setSelectedNodeId(nodeId);
        // You can fetch more detailed history here
    };

    const selectedNode = selectedNodeId ? nodes.find(n => n.node_id === selectedNodeId) : null;

    return (
        <ConnectionProvider endpoint={useMemo(() => clusterApiUrl(WalletAdapterNetwork.Devnet), [])}>
            <WalletProvider wallets={useMemo(() => [new PhantomWalletAdapter(), new SolflareWalletAdapter()], [])} autoConnect>
                <WalletModalProvider>
                    <div className="App">
                        <header className="App-header">
                            <h2>PoP-PoWeight Node Dashboard</h2>
                            <WalletMultiButton />
                            <WalletDisconnectButton />
                            {wallet.publicKey && <p>Connected: {wallet.publicKey.toBase58().substring(0, 8)}...</p>}
                            <p className="message">{message}</p>
                        </header>

                        <div className="section">
                            <h3>Register New Node</h3>
                            <input
                                type="text"
                                placeholder="Node Operator Public Key (Solana)"
                                value={newNodeOperator}
                                onChange={(e) => setNewNodeOperator(e.target.value)}
                            />
                            <input
                                type="text"
                                placeholder="Node Metadata URL (IPFS or similar)"
                                value={newNodeMetadataUrl}
                                onChange={(e) => setNewNodeMetadataUrl(e.target.value)}
                            />
                            <button onClick={handleRegisterNode} disabled={!wallet.connected}>Register Node</button>
                        </div>

                        <div className="section">
                            <h3>Registered Nodes</h3>
                            <button onClick={fetchNodes}>Refresh Nodes</button>
                            <div className="node-list">
                                {nodes.length === 0 ? (
                                    <p>No nodes registered yet.</p>
                                ) : (
                                    <ul>
                                        {nodes.map(node => (
                                            <li key={node.node_id}>
                                                <strong>ID:</strong> {node.node_id.substring(0, 8)}... <br />
                                                <strong>Operator:</strong> {node.operator_public_key.substring(0, 8)}... <br />
                                                <strong>Reputation:</strong> {node.reputation_score} ({node.reputation_tier}) <br />
                                                <strong>Sybil Risk:</strong> {node.sybil_risk_factor}% <br />
                                                <button onClick={() => handleViewNodeDetails(node.node_id)}>View Details</button>
                                                <button onClick={() => handleTriggerReputationRecalculation(node.node_id)} disabled={!wallet.connected}>
                                                    Recalculate Rep
                                                </button>
                                            </li>
                                        ))}
                                    </ul>
                                )}
                            </div>
                        </div>

                        {selectedNode && (
                            <div className="section node-details-modal">
                                <h3>Details for Node: {selectedNode.node_id.substring(0, 8)}...</h3>
                                <p><strong>Operator:</strong> {selectedNode.operator_public_key}</p>
                                <p><strong>Metadata:</strong> <a href={selectedNode.metadata_url} target="_blank" rel="noopener noreferrer">{selectedNode.metadata_url}</a></p>
                                <p><strong>Current Reputation:</strong> {selectedNode.reputation_score} ({selectedNode.reputation_tier})</p>
                                <p><strong>Sybil Risk Factor:</strong> {selectedNode.sybil_risk_factor}%</p>
                                <p><strong>Last Updated:</strong> {new Date(selectedNode.last_reputation_update).toLocaleString()}</p>
                                <button onClick={() => setSelectedNodeId(null)}>Close Details</button>
                            </div>
                        )}
                    </div>
                </WalletModalProvider>
            </WalletProvider>
        </ConnectionProvider>
    );
};

export default App;
```