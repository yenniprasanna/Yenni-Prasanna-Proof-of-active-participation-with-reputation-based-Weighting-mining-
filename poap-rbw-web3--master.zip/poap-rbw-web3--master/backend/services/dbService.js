```javascript
// backend/services/dbService.js - Database Service for PostgreSQL interactions
// This module provides functions to interact with the 'nodes', 'participation_events',
// and 'reputation_history' tables in your PostgreSQL database.

module.exports = (pool) => ({
    // --- Node Management Operations ---

    /**
     * Adds a new node to the database or updates an existing one if node_id conflicts.
     * @param {string} nodeId - The Solana PublicKey string of the NodeProfileAccount PDA.
     * @param {string} operatorPublicKey - The Solana PublicKey string of the node's operator.
     * @param {string} metadataUrl - URL to off-chain metadata for the node.
     * @returns {Promise<object>} The added or updated node record.
     */
    addNode: async (nodeId, operatorPublicKey, metadataUrl) => {
        const query = `
            INSERT INTO nodes (node_id, operator_public_key, metadata_url, reputation_score, reputation_tier, sybil_risk_factor, last_reputation_update, is_active)
            VALUES ($1, $2, $3, 0, 'Bronze', 0, NOW(), TRUE)
            ON CONFLICT (node_id) DO UPDATE SET
                operator_public_key = EXCLUDED.operator_public_key,
                metadata_url = EXCLUDED.metadata_url,
                is_active = TRUE,
                last_reputation_update = NOW() -- Update timestamp on conflict
            RETURNING *;
        `;
        const res = await pool.query(query, [nodeId, operatorPublicKey, metadataUrl]);
        return res.rows[0];
    },

    /**
     * Retrieves a node by its ID from the database.
     * @param {string} nodeId - The Solana PublicKey string of the NodeProfileAccount PDA.
     * @returns {Promise<object | undefined>} The node record, or undefined if not found.
     */
    getNodeById: async (nodeId) => {
        const query = `SELECT * FROM nodes WHERE node_id = $1;`;
        const res = await pool.query(query, [nodeId]);
        return res.rows[0]; // Returns undefined if no row found
    },

    /**
     * Retrieves all nodes from the database.
     * @returns {Promise<object[]>} An array of all node records.
     */
    getAllNodes: async () => {
        const query = `SELECT * FROM nodes;`;
        const res = await pool.query(query);
        return res.rows;
    },

    /**
     * Updates the reputation-related fields for a specific node.
     * @param {string} nodeId - The ID of the node to update.
     * @param {number} score - The new reputation score.
     * @param {string} tier - The new reputation tier.
     * @param {number} sybilRisk - The new sybil risk factor.
     * @param {number} lastUpdateTimestamp - Unix timestamp of the update.
     * @returns {Promise<object>} The updated node record.
     */
    updateNodeReputation: async (nodeId, score, tier, sybilRisk, lastUpdateTimestamp) => {
        const query = `
            UPDATE nodes
            SET reputation_score = $2, reputation_tier = $3, sybil_risk_factor = $4, last_reputation_update = TO_TIMESTAMP($5)
            WHERE node_id = $1
            RETURNING *;
        `;
        const res = await pool.query(query, [nodeId, score, tier, sybilRisk, lastUpdateTimestamp]);
        return res.rows[0];
    },

    // --- Participation Events Operations ---

    /**
     * Adds a new participation event record to the database.
     * @param {string} nodeId - The ID of the node associated with the event.
     * @param {string} activityType - Type of activity (e.g., 'BlockProposal').
     * @param {string} activityHash - Unique hash of the on-chain proof.
     * @param {number} timestamp - Unix timestamp of the activity.
     * @param {string} verifier - Public key of the entity that verified/submitted the proof.
     * @param {string} additionalDataUrl - URL to more details about the proof.
     * @returns {Promise<object>} The added participation event record.
     */
    addParticipationEvent: async (nodeId, activityType, activityHash, timestamp, verifier, additionalDataUrl) => {
        const query = `
            INSERT INTO participation_events (node_id, activity_type, activity_hash, timestamp, verifier, additional_data_url)
            VALUES ($1, $2, $3, TO_TIMESTAMP($4), $5, $6)
            ON CONFLICT (activity_hash) DO NOTHING -- Prevent duplicate events based on hash
            RETURNING *;
        `;
        const res = await pool.query(query, [nodeId, activityType, activityHash, timestamp, verifier, additionalDataUrl]);
        return res.rows[0]; // Will be undefined if ON CONFLICT DO NOTHING was triggered
    },

    /**
     * Retrieves all participation events for a specific node.
     * @param {string} nodeId - The ID of the node.
     * @returns {Promise<object[]>} An array of participation event records.
     */
    getParticipationEventsByNode: async (nodeId) => {
        const query = `SELECT * FROM participation_events WHERE node_id = $1 ORDER BY timestamp DESC;`;
        const res = await pool.query(query, [nodeId]);
        return res.rows;
    },

    // --- Reputation History Operations ---

    /**
     * Adds a historical record of a node's reputation change.
     * @param {string} nodeId - The ID of the node.
     * @param {number} score - The reputation score at that point.
     * @param {string} tier - The reputation tier at that point.
     * @param {number} sybilRisk - The sybil risk factor at that point.
     * @param {number} timestamp - Unix timestamp of the update.
     * @returns {Promise<object>} The added reputation history record.
     */
    addReputationHistory: async (nodeId, score, tier, sybilRisk, timestamp) => {
        const query = `
            INSERT INTO reputation_history (node_id, reputation_score, reputation_tier, sybil_risk_factor, timestamp)
            VALUES ($1, $2, $3, $4, TO_TIMESTAMP($5))
            RETURNING *;
        `;
        const res = await pool.query(query, [nodeId, score, tier, sybilRisk, timestamp]);
        return res.rows[0];
    },

    /**
     * Retrieves the reputation history for a specific node.
     * @param {string} nodeId - The ID of the node.
     * @returns {Promise<object[]>} An array of historical reputation records.
     */
    getReputationHistoryByNode: async (nodeId) => {
        const query = `SELECT * FROM reputation_history WHERE node_id = $1 ORDER BY timestamp ASC;`;
        const res = await pool.query(query, [nodeId]);
        return res.rows;
    },

    // Placeholder for other data retrieval functions if needed for ML module.
    // For instance, fetching raw transaction logs or token balances from DB if pre-processed.
    // fetchRawNodeData: async (nodeId) => { /* ... query various tables ... */ }
});
```