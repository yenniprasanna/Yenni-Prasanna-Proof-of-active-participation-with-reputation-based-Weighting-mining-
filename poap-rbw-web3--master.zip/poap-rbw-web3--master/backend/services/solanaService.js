```javascript
// backend/services/solanaService.js - Service for Solana Blockchain Interactions
// This module encapsulates interactions with the Solana blockchain,
// including calling program instructions and fetching on-chain data.

const { PublicKey, SystemProgram, Keypair, Connection } = require('@solana/web3.js');
const anchor = require('@project-serum/anchor');
const { Buffer } = require('buffer'); // For Node.js environments

module.exports = (connection, program, oracleKp, programID) => ({

    // --- On-chain Write Operations (Executed by the Backend Oracle) ---

    /**
     * Calls the `updateNodeReputation` instruction on the Solana program.
     * This action is typically performed by the trusted backend oracle.
     * @param {PublicKey} nodeIdPublicKey - The PublicKey of the NodeProfileAccount PDA.
     * @param {number} newScore - The new reputation score to set.
     * @param {string} tier - The new reputation tier.
     * @param {number} sybilRiskFactor - The new sybil risk factor.
     * @returns {Promise<string>} The transaction hash.
     */
    updateNodeReputationOnChain: async (nodeIdPublicKey, newScore, tier, sybilRiskFactor) => {
        try {
            // Find PDA for the oracle authority (must match the seed used in the Anchor program)
            const [expectedOraclePda] = PublicKey.findProgramAddressSync(
                [Buffer.from("oracle_authority_seed")], // Use your fixed seed here as defined in lib.rs
                programID
            );

            // Fetch the node profile from on-chain to get its operator's public key,
            // which is needed to derive the `node_profile` PDA seed.
            const nodeProfileAccount = await program.account.nodeProfileAccount.fetch(nodeIdPublicKey);
            
            // Re-derive the node_profile PDA to ensure it matches the one used in the instruction context.
            const [nodeProfilePda] = PublicKey.findProgramAddressSync(
                [Buffer.from("node_profile"), nodeProfileAccount.operator.toBuffer()], // Use operator pubkey as seed
                programID
            );

            console.log(`Updating reputation for Node: ${nodeIdPublicKey.toBase58()} with score: ${newScore}, tier: ${tier}`);

            // Call the Anchor program's instruction
            const tx = await program.methods
                .updateNodeReputation(new anchor.BN(newScore), tier, new anchor.BN(sybilRiskFactor))
                .accounts({
                    nodeProfile: nodeProfilePda,        // The PDA of the node's profile to update
                    oracleAuthority: oracleKp.publicKey, // The public key of the backend's oracle wallet (signer)
                    expectedOraclePda: expectedOraclePda, // The PDA used to verify the oracle's authority in the program
                    systemProgram: SystemProgram.programId, // Solana System Program
                })
                .signers([oracleKp]) // The backend's oracle keypair signs this transaction
                .rpc(); // Send the transaction to the Solana cluster

            console.log(`Reputation update transaction successful: ${tx}`);
            return tx;
        } catch (error) {
            console.error('Error updating node reputation on-chain:', error);
            throw error; // Re-throw to be caught by calling service/route
        }
    },

    // --- On-chain Read Operations ---

    /**
     * Fetches a NodeProfileAccount from the Solana blockchain.
     * @param {PublicKey} nodeIdPublicKey - The PublicKey of the NodeProfileAccount PDA.
     * @returns {Promise<object | null>} The deserialized NodeProfileAccount, or null if not found.
     */
    getNodeProfileOnChain: async (nodeIdPublicKey) => {
        try {
            const nodeProfileAccount = await program.account.nodeProfileAccount.fetch(nodeIdPublicKey);
            return nodeProfileAccount;
        } catch (error) {
            if (error.message.includes("Account does not exist")) {
                return null; // Node account not found on-chain
            }
            console.error('Error fetching node profile on-chain:', error);
            throw error;
        }
    },

    /**
     * (Conceptual) Fetches participation records for a node directly from on-chain.
     * For large datasets, it's generally more efficient to rely on PostgreSQL
     * which is populated by a dedicated Solana event listener service.
     * @param {PublicKey} nodeIdPublicKey - The PublicKey of the NodeProfileAccount PDA.
     * @returns {Promise<object[]>} An array of participation record accounts.
     */
    getParticipationRecordsOnChain: async (nodeIdPublicKey) => {
        try {
            // This is a simplified example. In a real application with many events,
            // fetching all accounts of a certain type and then filtering can be very expensive/slow.
            // It's highly recommended to use a dedicated event listener to stream
            // on-chain events into your PostgreSQL database for efficient querying.
            console.warn("getParticipationRecordsOnChain is a placeholder. For large data, rely on DB populated by event listeners.");
            return []; // Placeholder for actual implementation
        } catch (error) {
            console.error('Error fetching participation records on-chain:', error);
            throw error;
        }
    },

    // --- Other Solana RPC Functions (for ML data aggregation, if needed real-time) ---

    /**
     * Fetches recent transaction history for a given Solana public key.
     * @param {string} publicKey - The public key string of the wallet/account.
     * @returns {Promise<object[]>} An array of parsed transaction data.
     */
    getTxHistoryForWallet: async (publicKey) => {
        try {
            const pubKey = new PublicKey(publicKey);
            // Fetch transaction signatures, limit to 100 for example
            const signatures = await connection.getSignaturesForAddress(pubKey, { limit: 100 }); 
            const transactions = [];
            for (const sigInfo of signatures) {
                // Fetch full transaction details
                const tx = await connection.getParsedTransaction(sigInfo.signature, { maxSupportedTransactionVersion: 0 });
                if (tx) {
                    transactions.push({
                        signature: sigInfo.signature,
                        blockTime: tx.blockTime,
                        meta: tx.meta,
                        // You can parse more specific data here like instructions, involved programs, etc.
                    });
                }
            }
            return transactions;
        } catch (error) {
            console.error('Error fetching transaction history:', error);
            throw error;
        }
    },

    /**
     * Fetches token balances for a given Solana public key.
     * @param {string} publicKey - The public key string of the wallet/account.
     * @returns {Promise<object[]>} An array of token account details (mint, amount).
     */
    getTokenBalancesForWallet: async (publicKey) => {
        try {
            const pubKey = new PublicKey(publicKey);
            // Fetch parsed token accounts owned by the public key
            const tokenAccounts = await connection.getParsedTokenAccountsByOwner(pubKey, { programId: new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5mW') }); // SPL Token Program ID
            return tokenAccounts.value.map(ta => ({
                mint: ta.account.data.parsed.info.mint,        // Token Mint address
                amount: ta.account.data.parsed.info.tokenAmount.uiAmount, // UI friendly amount
            }));
        } catch (error) {
            console.error('Error fetching token balances:', error);
            throw error;
        }
    },
    // Add more Solana RPC functions here as needed for your ML model's data aggregation.
    // E.g., functions to fetch stake account details, validator vote history, etc.
});
```