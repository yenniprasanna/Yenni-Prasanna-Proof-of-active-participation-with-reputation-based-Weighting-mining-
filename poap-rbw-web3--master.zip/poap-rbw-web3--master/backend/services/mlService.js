```javascript
// backend/services/mlService.js - Service for ML Model Integration
// This module orchestrates fetching raw data, calling the Python ML model,
// and then storing the results both in the PostgreSQL database and on the Solana blockchain.

const { spawn } = require('child_process'); // Node.js module to run external processes
const path = require('path');               // Node.js module for path manipulation
const { PublicKey } = require('@solana/web3.js'); // For Solana PublicKey objects

module.exports = (pythonExecutablePath, dbPool) => { // Takes Python executable path and DB pool as arguments

    // Re-initialize dbService with the passed pool to ensure it has the correct DB connection
    const dbService = require('./dbService')(dbPool);

    // Construct the absolute path to your Python ML script
    const mlScriptPath = path.join(__dirname, '../ml_model/reputation_model.py');

    /**
     * Fetches and aggregates all necessary raw data for the ML model for a given node.
     * This includes data from the PostgreSQL database and potentially real-time Solana RPC data.
     * @param {string} nodeId - The string PublicKey of the node's PDA.
     * @returns {Promise<object>} An object containing all raw data for ML processing.
     */
    const fetchRawDataForML = async (nodeId) => {
        // 1. Fetch node profile from PostgreSQL
        const nodeProfile = await dbService.getNodeById(nodeId);
        if (!nodeProfile) {
            throw new Error(`Node ${nodeId} not found in DB. Cannot fetch raw data for ML.`);
        }
        
        // 2. Fetch participation events from PostgreSQL (these should be populated by event listeners)
        const participationEvents = await dbService.getParticipationEventsByNode(nodeId);
        
        // 3. Fetch real-time Solana blockchain data (example)
        // Accessing the solanaService instance that was initialized in server.js
        // This pattern (`require('../server').app.locals...`) is used to get globally available services.
        const solanaServiceInstance = require('./solanaService')( 
            require('../server').app.locals.solanaConnection, 
            require('../server').app.locals.solanaProgram,
            require('../server').app.locals.oracleKp,
            require('../server').app.locals.programID
        );
        
        // Fetch recent transaction history for the node's operator
        const txHistory = await solanaServiceInstance.getTxHistoryForWallet(nodeProfile.operator_public_key);
        // Fetch token balances for the node's operator
        const tokenBalances = await solanaServiceInstance.getTokenBalancesForWallet(nodeProfile.operator_public_key);
        // ... Add more data fetching (e.g., governance data, validator performance logs) as required by your ML model.

        // Aggregate all raw data into a single object
        return {
            nodeId: nodeId,
            operatorPublicKey: nodeProfile.operator_public_key,
            existingReputation: nodeProfile.reputation_score, // Include existing score if ML uses it
            participationEvents: participationEvents,
            txHistory: txHistory,
            tokenBalances: tokenBalances,
            // ... add more raw data fields here
        };
    };

    /**
     * Executes the Python ML script with the raw data and parses its output.
     * @param {string} nodeId - The string PublicKey of the node.
     * @param {object} rawData - The raw data fetched for the ML model.
     * @returns {Promise<object>} The parsed JSON result from the Python script (e.g., new score, tier, risk).
     */
    const calculateReputationWithMl = async (nodeId, rawData) => {
        return new Promise((resolve, reject) => {
            console.log(`Calling Python ML script for node: ${nodeId}`);
            // Spawn a new Python process. Pass the script path and rawData as JSON string arguments.
            const python = spawn(pythonExecutablePath, [mlScriptPath, nodeId, JSON.stringify(rawData)]);

            let dataToSend = ''; // Buffer for stdout from Python script
            python.stdout.on('data', (data) => {
                dataToSend += data.toString();
            });

            // Log any errors from the Python script's stderr
            python.stderr.on('data', (data) => {
                console.error(`Python Error for ${nodeId}: ${data.toString()}`);
            });

            // Handle Python process closing
            python.on('close', (code) => {
                if (code === 0) { // Python script exited successfully
                    try {
                        const result = JSON.parse(dataToSend); // Parse the JSON output from Python
                        console.log(`ML Result for ${nodeId}:`, result);
                        resolve(result);
                    } catch (parseError) {
                        console.error('Failed to parse Python output:', parseError);
                        reject(new Error(`Invalid ML output: ${dataToSend}`));
                    }
                } else { // Python script exited with an error code
                    reject(new Error(`Python script exited with code ${code} for node ${nodeId}. Check Python errors in logs.`));
                }
            });

            // Handle errors in spawning the Python process itself
            python.on('error', (err) => {
                console.error(`Failed to start Python process: ${err.message}`);
                reject(err);
            });
        });
    };

    return {
        /**
         * Orchestrates the entire reputation calculation and update process for a node.
         * Fetches data, calls ML, stores results in DB, and updates on-chain.
         * @param {string} nodeIdString - The string PublicKey of the node's PDA.
         * @returns {Promise<object>} An object indicating success, new reputation, and transaction hash.
         */
        calculateAndStoreNodeReputation: async (nodeIdString) => {
            const nodeId = new PublicKey(nodeIdString); // Convert string ID to PublicKey object

            try {
                // 1. Fetch comprehensive raw data for the ML model
                const rawData = await fetchRawDataForML(nodeIdString); // Pass string ID to data fetching

                // 2. Call the Python ML model to get new reputation metrics
                const mlResult = await calculateReputationWithMl(nodeIdString, rawData);
                const { reputation_score, reputation_tier, sybil_risk_factor } = mlResult;

                // 3. Store the new reputation in the PostgreSQL database
                const updatedNodeInDb = await dbService.updateNodeReputation(
                    nodeIdString,
                    reputation_score,
                    reputation_tier,
                    sybil_risk_factor,
                    Math.floor(Date.now() / 1000) // Current Unix timestamp for update
                );
                console.log(`Node ${nodeIdString} reputation updated in DB.`);
                
                // 4. Add a record to the reputation history table
                await dbService.addReputationHistory(
                    nodeIdString,
                    reputation_score,
                    reputation_tier,
                    sybil_risk_factor,
                    Math.floor(Date.now() / 1000) // Timestamp for the history record
                );

                // 5. Update the on-chain reputation for the node using the backend as the oracle
                const solanaServiceInstance = require('./solanaService')( // Re-get service instance
                    require('../server').app.locals.solanaConnection,
                    require('../server').app.locals.solanaProgram,
                    require('../server').app.locals.oracleKp,
                    require('../server').app.locals.programID
                );
                const txHash = await solanaServiceInstance.updateNodeReputationOnChain(
                    nodeId, // Pass PublicKey object to Solana service
                    reputation_score,
                    reputation_tier,
                    sybil_risk_factor
                );
                console.log(`Node ${nodeIdString} reputation updated on-chain. Tx: ${txHash}`);

                return { success: true, newReputation: reputation_score, txHash };

            } catch (error) {
                console.error(`Failed to calculate and update reputation for node ${nodeIdString}:`, error);
                throw error; // Re-throw to be caught by the API route
            }
        },
    };
};
```