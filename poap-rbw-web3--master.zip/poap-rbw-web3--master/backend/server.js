```javascript
// backend/server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');
const { Connection, PublicKey, Keypair } = require('@solana/web3.js');
const anchor = require('@project-serum/anchor');
const { Buffer } = require('buffer'); // Ensure Buffer is available for Keypair fromSecretKey

// Import your program IDL (adjust path relative to server.js)
// This file will be generated in target/idl after 'anchor build' and copied to frontend/src
const idl = require('../target/idl/poap_rbw_web3.json'); 

// Import custom service and route modules
const dbService = require('./services/dbService');
const solanaService = require('./services/solanaService');
const mlService = require('./services/mlService');
const nodesRoutes = require('./routes/nodesRoutes');
const reputationRoutes = require('./routes/reputationRoutes');

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors()); // Enable CORS for frontend communication
app.use(express.json()); // Parse JSON request bodies

// --- Database Setup ---
const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: parseInt(process.env.DB_PORT || '5432'),
});

// Test database connection on startup
pool.connect((err, client, release) => {
    if (err) {
        console.error('Error acquiring database client:', err.stack);
        process.exit(1); // Exit if DB connection fails
    }
    client.query('SELECT NOW()', (err, result) => {
        release(); // Release the client back to the pool
        if (err) {
            console.error('Error executing DB query (connection test):', err.stack);
            process.exit(1);
        }
        console.log('PostgreSQL database connected:', result.rows[0].now);
    });
});
app.locals.db = pool; // Make DB pool available to routes/services via app.locals

// --- Solana Connection & Program Setup (for Backend Oracle) ---
// Connect to the Solana devnet validator running in the 'solana-dev' Docker container
const solanaConnection = new Connection(process.env.SOLANA_RPC_URL || 'http://solana-dev:8899', 'confirmed');
const programID = new PublicKey(process.env.SOLANA_PROGRAM_ID || idl.metadata.address);

// Oracle Wallet (backend's identity to sign on-chain reputation updates)
let oracleKp;
try {
    const pkArray = JSON.parse(process.env.ORACLE_PRIVATE_KEY_ARRAY || '[]');
    if (pkArray.length !== 64) {
        throw new Error("ORACLE_PRIVATE_KEY_ARRAY is not a valid 64-byte array. It must contain 64 numbers for a Solana Keypair.");
    }
    oracleKp = Keypair.fromSecretKey(Buffer.from(pkArray));
    console.log("Oracle Public Key:", oracleKp.publicKey.toBase58());
} catch (error) {
    console.error("Error loading Oracle Private Key:", error);
    console.error("Please ensure ORACLE_PRIVATE_KEY_ARRAY is correctly set in backend/.env with your 64-number keypair array.");
    process.exit(1); // Exit if oracle key is invalid
}

// Create an Anchor Provider for the backend's oracle operations
const oracleProvider = new anchor.AnchorProvider(
    solanaConnection,
    new anchor.Wallet(oracleKp),
    anchor.AnchorProvider.defaultOptions()
);
// Initialize the Anchor program client using the IDL and Program ID
const solanaProgram = new anchor.Program(idl, programID, oracleProvider);

// Make Solana connection and program available to other modules
app.locals.solanaConnection = solanaConnection;
app.locals.solanaProgram = solanaProgram;
app.locals.oracleKp = oracleKp;
app.locals.programID = programID; // Make program ID available

// --- Attach Services to app.locals for easy access in routes ---
// Initialize services with their dependencies (DB pool, Solana connection/program, etc.)
app.locals.dbService = dbService(pool);
app.locals.solanaService = solanaService(solanaConnection, solanaProgram, oracleKp, programID);
app.locals.mlService = mlService(process.env.PYTHON_ENV_PATH || './.venv/bin/python', pool); // Python path relative to backend directory

// --- API Routes ---
app.use('/api/nodes', nodesRoutes); // Routes for node management
app.use('/api/reputation', reputationRoutes); // Routes for reputation calculation/updates

// General health check endpoint
app.get('/', (req, res) => {
    res.send('PoP-PoWeight Backend is running and ready!');
});

// Global Error Handling Middleware
// Catches errors passed via `next(error)` from routes/services
app.use((err, req, res, next) => {
    console.error('Global Error Handler:', err.stack); // Log full error stack
    res.status(err.statusCode || 500).json({
        message: err.message || 'An unexpected error occurred.',
        error: process.env.NODE_ENV === 'production' ? {} : err.stack, // Send stack only in dev
    });
});

// Start the HTTP server
app.listen(port, () => {
    console.log(`Backend server running on http://localhost:${port}`);
    // Optional: Implement a periodic job to recalculate reputation for all active nodes.
    // This would typically involve fetching all active nodes from the DB
    // and then calling `app.locals.mlService.calculateAndStoreNodeReputation` for each.
    // Example (uncomment and adjust interval as needed):
    // setInterval(async () => {
    //     console.log("Triggering periodic reputation recalculation for all active nodes...");
    //     try {
    //         const activeNodes = await app.locals.dbService.getAllNodes(); // Or get only active ones
    //         for (const node of activeNodes) {
    //             if (node.is_active) {
    //                 await app.locals.mlService.calculateAndStoreNodeReputation(node.node_id);
    //             }
    //         }
    //         console.log("Periodic reputation recalculation completed.");
    //     } catch (err) {
    //         console.error("Error during periodic reputation recalculation:", err);
    //     }
    // }, 1 * 60 * 60 * 1000); // Run every 1 hour (adjust as needed for your project)
});
```