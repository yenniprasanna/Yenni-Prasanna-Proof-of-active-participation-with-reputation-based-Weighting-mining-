```javascript
// backend/routes/reputationRoutes.js - API Routes for Reputation Management
// This module handles API requests related to triggering reputation calculations
// and retrieving reputation data.

const express = require('express');
const router = express.Router();

/**
 * POST /api/reputation/calculate/:nodeId
 * Endpoint to manually trigger the reputation calculation and update process for a specific node.
 * This is typically an admin or internal endpoint.
 * @param {string} nodeId - The Solana PublicKey string of the node's PDA.
 */
router.post('/calculate/:nodeId', async (req, res, next) => {
    const { nodeId } = req.params; // Expecting Solana PublicKey string for the node
    const { mlService } = req.app.locals; // Access mlService instance from app locals

    try {
        console.log(`Received request to recalculate reputation for node: ${nodeId}`);
        // Call the ML service to orchestrate the calculation, DB update, and on-chain update.
        const result = await mlService.calculateAndStoreNodeReputation(nodeId);
        res.json({ message: 'Reputation calculation and update triggered successfully', ...result });
    } catch (error) {
        console.error(`API Error for /calculate/${nodeId}:`, error);
        next(error); // Pass error to global error handler
    }
});

/**
 * GET /api/reputation/:nodeId
 * Retrieves a node's current reputation score, tier, and sybil risk from the backend's PostgreSQL DB.
 */
router.get('/:nodeId', async (req, res, next) => {
    const { nodeId } = req.params;
    const { dbService } = req.app.locals; // Access dbService

    try {
        const node = await dbService.getNodeById(nodeId);
        if (!node) {
            return res.status(404).json({ error: 'Node not found in backend DB.' });
        }
        // Return only relevant reputation fields
        res.json({
            node_id: node.node_id,
            reputation_score: node.reputation_score,
            reputation_tier: node.reputation_tier,
            sybil_risk_factor: node.sybil_risk_factor,
            last_reputation_update: node.last_reputation_update,
        });
    } catch (error) {
        next(error);
    }
});

/**
 * POST /api/reputation/listen-events
 * (Conceptual) Endpoint for an external Solana event listener to push on-chain events
 * to the backend for database processing.
 * This would be part of a separate, dedicated event listener service in a larger application.
 */
router.post('/listen-events', async (req, res, next) => {
    // This endpoint would receive events from a Solana event listener (e.g., from your frontend or another service)
    // For demonstration, let's assume `req.body` contains an event like 'ParticipationRecordedEvent'
    const { eventType, eventData } = req.body;
    const { dbService } = req.app.locals;

    try {
        if (eventType === 'ParticipationRecordedEvent') {
            const { node_id, activity_type, activity_hash, timestamp, verifier, additional_data_url } = eventData;
            const addedEvent = await dbService.addParticipationEvent(node_id, activity_type, activity_hash, timestamp, verifier, additional_data_url);
            if (addedEvent) {
                console.log(`DB updated with ParticipationRecordedEvent for node ${node_id}.`);
                // Optionally, trigger ML recalculation immediately after a new participation event
                // await req.app.locals.mlService.calculateAndStoreNodeReputation(node_id);
            } else {
                console.log(`Duplicate ParticipationRecordedEvent for node ${node_id} (hash: ${activity_hash}). Not added.`);
            }
            res.status(200).json({ message: 'Event processed and DB updated (if not duplicate).' });
        } else if (eventType === 'ReputationUpdatedEvent') {
             const { node_id, new_score, timestamp, tier, sybil_risk } = eventData;
             await dbService.updateNodeReputation(node_id, new_score, tier, sybil_risk, timestamp);
             await dbService.addReputationHistory(node_id, new_score, tier, sybil_risk, timestamp);
             console.log(`DB updated with ReputationUpdatedEvent for node ${node_id}.`);
             res.status(200).json({ message: 'Reputation event processed.' });
        } else {
            res.status(400).json({ error: 'Unknown event type.' });
        }
    } catch (error) {
        console.error('Error processing event:', error);
        next(error);
    }
});


module.exports = router;
```