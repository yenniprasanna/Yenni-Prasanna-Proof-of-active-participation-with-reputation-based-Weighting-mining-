```javascript
// backend/routes/nodesRoutes.js - API Routes for Node Management
// This module handles API requests related to registering, fetching, and managing nodes.

const express = require('express');
const router = express.Router();
const { PublicKey } = require('@solana/web3.js'); // For Solana PublicKey validation
const anchor = require('@project-serum/anchor');    // For web3.SystemProgram
const { Buffer } = require('buffer');               // For buffer needed with PDA seeds

/**
 * POST /api/nodes/register
 * Registers a new node both on-chain and in the off-chain database.
 * Body: { nodeId: string, operatorPublicKey: string, nodeMetadataUrl: string }
 */
router.post('/register', async (req, res, next) => {
    const { nodeId, operatorPublicKey, nodeMetadataUrl } = req.body;
    // Access services and Solana program info from Express app locals
    const { dbService, solanaProgram, oracleKp, programID } = req.app.locals; 

    try {
        // Basic input validation
        if (!nodeId || !operatorPublicKey || !nodeMetadataUrl) {
            return res.status(400).json({ error: 'Missing required fields: nodeId, operatorPublicKey, nodeMetadataUrl.' });
        }
        
        // Validate and convert public keys
        const operatorPubKey = new PublicKey(operatorPublicKey);
        const nodeIdPubKey = new PublicKey(nodeId); // Expected PDA of the NodeProfileAccount

        // Verify if the provided nodeId matches the PDA derived from the operator's public key
        const [expectedNodeProfilePda] = PublicKey.findProgramAddressSync(
            [Buffer.from("node_profile"), operatorPubKey.toBuffer()], // Seeds must match lib.rs
            programID
        );
        if (!nodeIdPubKey.equals(expectedNodeProfilePda)) {
            return res.status(400).json({ error: `Provided nodeId (${nodeId}) does not match expected PDA derived from operatorPublicKey (${expectedNodeProfilePda.toBase58()}).` });
        }

        // --- On-chain registration via Solana program ---
        // The `registerNode` instruction is called.
        // For this example, the backend's `oracleKp` (acting as an admin/payer) signs this.
        // In a production setup, the actual `node_operator` might be expected to sign this transaction.
        const tx = await solanaProgram.methods.registerNode(nodeMetadataUrl)
            .accounts({
                nodeProfile: nodeIdPubKey,        // The PDA account to be initialized
                operator: oracleKp.publicKey,     // The account paying for the transaction (and defined as operator in contract)
                systemProgram: anchor.web3.SystemProgram.programId, // Solana System Program
            })
            .signers([oracleKp]) // The backend's oracle keypair signs the transaction
            .rpc(); // Send the transaction to the Solana cluster

        console.log(`Node ${nodeId} registered on-chain. Tx: ${tx}`);

        // --- Off-chain database storage ---
        // After successful on-chain registration, record the node in your PostgreSQL database.
        const newNode = await dbService.addNode(nodeId, operatorPublicKey, nodeMetadataUrl);
        
        res.status(201).json({ message: 'Node registered successfully', node: newNode, txHash: tx });
    } catch (error) {
        console.error('Error registering node:', error);
        next(error); // Pass error to global error handler middleware
    }
});

/**
 * GET /api/nodes/:nodeId
 * Retrieves a single node's details from the off-chain database.
 */
router.get('/:nodeId', async (req, res, next) => {
    const { nodeId } = req.params;
    const { dbService } = req.app.locals; // Access dbService

    try {
        const node = await dbService.getNodeById(nodeId);
        if (!node) {
            return res.status(404).json({ error: 'Node not found.' });
        }
        res.json(node);
    } catch (error) {
        next(error);
    }
});

/**
 * GET /api/nodes/
 * Retrieves all registered nodes from the off-chain database.
 */
router.get('/', async (req, res, next) => {
    const { dbService } = req.app.locals;
    try {
        const nodes = await dbService.getAllNodes();
        res.json(nodes);
    } catch (error) {
        next(error);
    }
});

/**
 * GET /api/nodes/:nodeId/participation-events
 * Retrieves all participation events for a specific node from the off-chain database.
 */
router.get('/:nodeId/participation-events', async (req, res, next) => {
    const { nodeId } = req.params;
    const { dbService } = req.app.locals;
    try {
        const events = await dbService.getParticipationEventsByNode(nodeId);
        res.json(events);
    } catch (error) {
        next(error);
    }
});

/**
 * GET /api/nodes/:nodeId/reputation-history
 * Retrieves the reputation history for a specific node from the off-chain database.
 */
router.get('/:nodeId/reputation-history', async (req, res, next) => {
    const { nodeId } = req.params;
    const { dbService } = req.app.locals;
    try {
        const history = await dbService.getReputationHistoryByNode(nodeId);
        res.json(history);
    } catch (error) {
        next(error);
    }
});


module.exports = router;
```