```python
# backend/ml_model/reputation_model.py - Python ML Module for Reputation Calculation
# This script is executed by the Node.js backend. It receives raw data,
# engineers features, and outputs a calculated reputation score, tier, and sybil risk.

import sys
import json
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler # Example import for numerical features
# from sklearn.ensemble import RandomForestRegressor # Example: For predicting continuous score
# from sklearn.cluster import KMeans # Example: For clustering nodes into tiers
# from sklearn.svm import OneClassSVM # Example: For anomaly/Sybil detection

def engineer_features(raw_data):
    """
    Transforms raw, comprehensive data for a node into numerical features
    suitable for the ML model. This is where the 'quality' assessment starts.

    Args:
        raw_data (dict): A dictionary containing all raw data for a node.

    Returns:
        pd.DataFrame: A DataFrame with a single row representing the engineered features.
    """
    features = {}

    # --- 1. Proof of Participation (PoP) Features ---
    # These features quantify a node's verifiable on-chain activities.
    poaps = raw_data.get('participationEvents', [])
    features['num_poaps'] = len(poaps) # Total number of participation events
    
    # Count specific PoP types (customize based on your defined activity types)
    features['num_block_proposals'] = sum(1 for p in poaps if p['activity_type'] == 'BlockProposal')
    features['num_governance_votes'] = sum(1 for p in poaps if p['activity_type'] == 'GovernanceVote')
    features['num_code_contributions'] = sum(1 for p in poaps if p['activity_type'] == 'CodeContribution')

    # Assess recency and frequency of participation
    if poaps:
        # Timestamps from PostgreSQL are typically Unix timestamps
        latest_timestamp = max(p['timestamp'] for p in poaps)
        oldest_timestamp = min(p['timestamp'] for p in poaps)
        
        # Duration of activity in seconds
        features['poap_activity_duration'] = latest_timestamp - oldest_timestamp 
        
        # Average frequency of PoPs (events per second/day etc.). Add 1 to duration to avoid division by zero.
        features['avg_poap_frequency'] = features['num_poaps'] / (features['poap_activity_duration'] + 1)
    else:
        features['poap_activity_duration'] = 0
        features['avg_poap_frequency'] = 0

    # --- 2. Transaction History Features ---
    # These are derived from Solana transaction logs (fetched via RPC or pre-processed in DB).
    tx_history = raw_data.get('txHistory', {})
    features['total_successful_txns'] = tx_history.get('successful_txns', 0) # Placeholder: Assume pre-processed
    features['unique_programs_interacted'] = tx_history.get('unique_programs_interacted', 0) # Placeholder
    features['avg_tx_value_sol'] = tx_history.get('avg_tx_value_sol', 0) # Placeholder

    # --- 3. Token Holdings Features ---
    # These reflect a node's economic stake or participation.
    token_balances = raw_data.get('tokenBalances', [])
    features['num_unique_tokens'] = len(token_balances)
    # Example: Total SOL held (replace 'So111...' with actual SOL mint if needed, usually it's null/implicit)
    # If the Solana service returns amounts for 'SOL' directly, adjust this.
    features['total_sol_held'] = sum(t['amount'] for t in token_balances if t['mint'] == 'So11111111111111111111111111111111111111112') 
    # Add logic for other important tokens (e.g., stablecoins, governance tokens)

    # --- 4. Governance Activity Features ---
    # Metrics related to participation in on-chain governance.
    gov_activity = raw_data.get('governanceActivity', {})
    features['votes_cast'] = gov_activity.get('votes_cast', 0)
    features['proposals_authored'] = gov_activity.get('proposals_authored', 0)
    features['successful_governance_votes'] = gov_activity.get('passed_votes', 0)

    # Define all expected feature names. This ensures the DataFrame has consistent columns,
    # even if a feature is zero for a given node.
    feature_names = [
        'num_poaps', 'num_block_proposals', 'num_governance_votes', 'num_code_contributions',
        'poap_activity_duration', 'avg_poap_frequency',
        'total_successful_txns', 'unique_programs_interacted', 'avg_tx_value_sol',
        'num_unique_tokens', 'total_sol_held',
        'votes_cast', 'proposals_authored', 'successful_governance_votes'
    ]
    
    # Create a Pandas DataFrame with a single row for the current node's features.
    # This prepares the data in a format typically expected by scikit-learn models.
    df_features = pd.DataFrame([features])[feature_names] # Ensure consistent columns
    
    return df_features

def predict_reputation(features_df):
    """
    Applies the trained ML model to predict reputation score, tier, and sybil risk.

    Args:
        features_df (pd.DataFrame): DataFrame containing engineered features for a node.

    Returns:
        dict: A dictionary containing 'reputation_score', 'reputation_tier', and 'sybil_risk_factor'.
    """
    # Placeholder for actual ML model loading and prediction
    # In a real scenario, you would:
    # 1. Load a pre-trained feature scaler (e.g., StandardScaler):
    #    `scaler = joblib.load('path/to/scaler.pkl')`
    # 2. Scale your features:
    #    `scaled_features = scaler.transform(features_df)`
    # 3. Load your trained reputation prediction model (e.g., RandomForestRegressor):
    #    `reputation_model = joblib.load('path/to/reputation_model.pkl')`
    # 4. Predict the score:
    #    `score = reputation_model.predict(scaled_features)[0]`
    # 5. Load your trained tier classification/clustering model (e.g., KMeans):
    #    `tier_model = joblib.load('path/to/tier_model.pkl')`
    # 6. Predict the tier:
    #    `tier_cluster = tier_model.predict(scaled_features)[0]`
    #    Then map cluster ID to tier string (e.g., 0->Bronze, 1->Silver, 2->Gold)
    # 7. Load your trained sybil detection model (e.g., OneClassSVM, IsolationForest):
    #    `sybil_model = joblib.load('path/to/sybil_model.pkl')`
    # 8. Predict sybil risk (e.g., anomaly score, or binary classification 0/1 mapped to risk factor):
    #    `sybil_anomaly_score = sybil_model.decision_function(scaled_features)[0]`
    #    `sybil_risk = some_function_of(sybil_anomaly_score)`

    # --- For this example, we'll use a simple rule-based system ---
    # This simulates the ML output based on the engineered features for demonstration purposes.
    score = 0
    if not features_df.empty:
        f = features_df.iloc[0] # Get the single row of features

        # Simple weighted sum for score (weights would be optimized by ML model training)
        score = (
            f['num_block_proposals'] * 20 +
            f['num_governance_votes'] * 15 +
            f['num_code_contributions'] * 25 +
            f['avg_poap_frequency'] * 50000 + # Scaling for frequency
            f['total_successful_txns'] * 0.01 + # Small contribution
            f['unique_programs_interacted'] * 0.5 +
            f['total_sol_held'] * 0.1 +
            f['successful_governance_votes'] * 10
        )
        score = min(max(score, 0), 1000) # Cap score within a range, e.g., 0-1000

    tier = "Bronze"
    if score >= 800:
        tier = "Gold"
    elif score >= 500:
        tier = "Silver"
    
    sybil_risk = 0
    # Simple rule for sybil risk (would be from a dedicated ML model)
    # Example: If a node has high transaction volume but very few verifiable participation events.
    if f['total_successful_txns'] > 500 and f['num_poaps'] < 3 and f['total_sol_held'] < 10:
        sybil_risk = 90 # Very High Risk
    elif f['total_successful_txns'] > 100 and f['num_poaps'] < 1:
        sybil_risk = 70 # High Risk
    elif f['total_successful_txns'] > 50 and f['num_poaps'] < 2:
        sybil_risk = 40 # Medium Risk
    
    return {
        "reputation_score": int(score),          # Ensure integer for DB
        "reputation_tier": tier,
        "sybil_risk_factor": int(sybil_risk)     # Ensure integer for DB
    }

if __name__ == "__main__":
    # This block executes when the script is run directly (e.g., by Node.js spawn)
    if len(sys.argv) > 2: # Expecting nodeId as sys.argv[1] and rawData JSON string as sys.argv[2]
        node_id_string = sys.argv[1]
        raw_data_json_string = sys.argv[2] 
        
        try:
            raw_data = json.loads(raw_data_json_string) # Parse the incoming JSON string
            engineered_features = engineer_features(raw_data) # Engineer features
            prediction = predict_reputation(engineered_features) # Get ML predictions
            
            # Output the final result as a JSON string to stdout.
            # This output will be captured by the Node.js parent process.
            print(json.dumps({
                "node_id": node_id_string,
                **prediction # Unpack the prediction dictionary into the output JSON
            }))
            
        except json.JSONDecodeError as e:
            # Handle JSON parsing errors (e.g., malformed input from Node.js)
            print(json.dumps({"error": f"Invalid JSON input to Python ML script: {e}", "raw_input_sample": raw_data_json_string[:200]}), file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            # Catch any other exceptions during script execution
            print(json.dumps({"error": f"An error occurred during ML processing: {str(e)}", "node_id": node_id_string}), file=sys.stderr)
            sys.exit(1)
    else:
        # Error if not enough arguments are provided
        print(json.dumps({"error": "No data or node ID provided to ML script."}), file=sys.stderr)
        sys.exit(1)

```